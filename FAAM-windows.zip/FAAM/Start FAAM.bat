@echo off
setlocal enabledelayedexpansion
cd /d "%~dp0"
title FAAM

REM --- Find a Python that actually runs (skip the Microsoft Store stub) ---
set "PYEXE="
for %%P in (py python python3) do (
  if not defined PYEXE (
    %%P -c "import sys" >nul 2>nul && set "PYEXE=%%P"
  )
)
if not defined PYEXE (
  echo.
  echo   Python 3 was not found.
  echo   1^) Install it from https://www.python.org/downloads/
  echo   2^) During setup, TICK "Add Python to PATH"
  echo   3^) Then double-click this file again.
  echo.
  echo   Tip: if typing "python" opens the Microsoft Store, turn off the
  echo   python alias in Settings ^> Manage App Execution Aliases.
  echo.
  pause
  exit /b 1
)

REM --- Keys: bundled with this download, or kept from a previous run. ---
REM Never prompts. Stock data needs no key at all, so the dashboard is always live.
set "FAAM_DIR=%USERPROFILE%\.faam"
set "FAAM_KEY=%FAAM_DIR%\key"
if not defined OPENAI_API_KEY if exist "%~dp0key" set /p OPENAI_API_KEY=<"%~dp0key"
if not defined OPENAI_API_KEY if exist "%FAAM_KEY%" set /p OPENAI_API_KEY=<"%FAAM_KEY%"
if defined OPENAI_API_KEY (
  if not exist "%FAAM_DIR%" mkdir "%FAAM_DIR%" >nul 2>nul
  >"%FAAM_KEY%" echo(!OPENAI_API_KEY!
)
if not defined ALPHAVANTAGE_API_KEY if exist "%~dp0alphavantage_key" set /p ALPHAVANTAGE_API_KEY=<"%~dp0alphavantage_key"

echo.
echo   Starting FAAM... your browser will open automatically in a moment.
echo   Keep this window open while you use FAAM. Close it to quit.
echo.

REM --- Open the browser only once the server answers (runs in background) ---
start "" /b powershell -NoProfile -WindowStyle Hidden -Command "$ErrorActionPreference='SilentlyContinue';for($i=0;$i -lt 90;$i++){try{$r=Invoke-WebRequest -UseBasicParsing 'http://localhost:8765/api/health' -TimeoutSec 1;if($r.StatusCode -eq 200){Start-Process 'http://localhost:8765/dashboard';break}}catch{};Start-Sleep -Milliseconds 500}"

%PYEXE% app.py
echo.
echo   FAAM has stopped.
pause
