FAAM for Linux
==============

QUICK START
  1) Check Python 3 is installed:   python3 --version
  2) From this folder, run:         ./run-faam.sh
        (or, if it isn't executable:  bash run-faam.sh)
  3) Paste your FAAM AI key if asked — optional, stored at ~/.faam/key.
  4) Your browser opens to FAAM. Create an account or sign in, and you're in.

ADD TO YOUR APPS MENU (optional)
  ./install.sh
  Then launch "FAAM" from your applications menu, or run:  faam

FAAM is pure Python and runs entirely on your machine — nothing to install
beyond Python 3. It never places trades; it prepares orders for you to review.
Not financial advice.
